#!/bin/bash

# 系统架构

architecture=$(uname -m)

# 启动时间

uptime_output=$(uptime)

# 提取出类似 "up 1 day, 2 hours, 3 minutes" 这样的字符串

uptime_info=$(echo "$uptime_output" | grep -oP '(?<=up )[^,]+(?:, [^,]+)*')

if [ -z "$uptime_info" ]; then

    uptime="未获取到有效启动时间信息"

else

    uptime="已运行 $uptime_info"

fi

# CPU信息

cpu_model=$(grep "model name" /proc/cpuinfo | head -1 | awk -F': ' '{print $2}')

cpu_cores=$(grep -c "processor" /proc/cpuinfo)

cpu_usage=$(top -bn1 | grep "Cpu(s)" | awk '{print $2 + $4}')

# 内存信息

total_memory=$(free -h | awk '/Mem:/ {print $2}')

used_memory=$(free -h | awk '/Mem:/ {print $3}')

memory_usage=$(free -h | awk '/Mem:/ {print $3 "/" $2}')

# 磁盘信息

disk_usage=$(df -h | awk '$NF=="/"{print $3 "/" $2 " used, " $5 " used percentage"}')

# 网络信息

ip_address=$(ip addr show | grep -Eo 'inet (addr:)?([0-9]*\.){3}[0-9]*' | grep -Eo '([0-9]*\.){3}[0-9]*' | grep -v '127.0.0.1' | head -1)

iface=$(ip route | awk '/default/ {print $5}')

# 内核版本

kernel_version=$(uname -r)

# 主机名

hostname=$(hostname)

# 输出信息

echo "系统架构: $architecture"

echo "启动时间: $uptime"

echo "CPU型号: $cpu_model"

echo "CPU核心数: $cpu_cores"

echo "CPU占用: $cpu_usage%"

echo "总内存: $total_memory"

echo "已用内存: $used_memory"

echo "内存占用: $memory_usage"

echo "磁盘使用情况: $disk_usage"

echo "IP地址: $ip_address"

echo "网络接口: $iface"

echo "内核版本: $kernel_version"

echo "主机名: $hostname"

